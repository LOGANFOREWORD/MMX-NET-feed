// Copyright (c) 2026 R1nk1
// Licensed under the R1 Non-Monetized Modpack License v1.0
// License: https://github.com/noname-r1nk1/R1-License
#include "common.h"
#include "skin.h"
#include "r1ev_glass_io.h"
r1ev_glass_vf _main(v_model v) {
 r1ev_glass_vf o;
 float3 world=mul(m_W,v.P).xyz;
 float3 normal=normalize(mul((float3x3)m_W,v.N.xyz));
 o.hpos=mul(m_WVP,v.P);
 o.uv=v.tc.xy*1.6+float2(timers.x*.024,-timers.x*.035);
 o.reflection=calc_reflection(world,normal);
 o.fresnel=pow(1-saturate(abs(dot(normal,normalize(eye_position-world)))),2.5);
 o.fog=saturate(calc_fogging(float4(world,1)));
 return o;
}
#ifdef SKIN_NONE
r1ev_glass_vf main(v_model v){return _main(v);}
#endif
#ifdef SKIN_0
r1ev_glass_vf main(v_model_skinned_0 v){return _main(skinning_0(v));}
#endif
#ifdef SKIN_1
r1ev_glass_vf main(v_model_skinned_1 v){return _main(skinning_1(v));}
#endif
#ifdef SKIN_2
r1ev_glass_vf main(v_model_skinned_2 v){return _main(skinning_2(v));}
#endif
#ifdef SKIN_3
r1ev_glass_vf main(v_model_skinned_3 v){return _main(skinning_3(v));}
#endif
#ifdef SKIN_4
r1ev_glass_vf main(v_model_skinned_4 v){return _main(skinning_4(v));}
#endif
