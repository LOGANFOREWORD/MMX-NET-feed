// Copyright (c) 2026 R1nk1
// Licensed under the R1 Non-Monetized Modpack License v1.0
// License: https://github.com/noname-r1nk1/R1-License
#ifndef R1EV_GLASS_IO
#define R1EV_GLASS_IO
struct r1ev_glass_vf {
 float2 uv:TEXCOORD0;
 float3 reflection:TEXCOORD1;
 float fresnel:TEXCOORD2;
 float fog:FOG;
 float4 hpos:SV_Position;
};
#endif
