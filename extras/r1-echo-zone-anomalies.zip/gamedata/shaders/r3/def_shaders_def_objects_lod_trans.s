-- R1nk1 modifications only: automatic dispatch / foliage integration.
-- Copyright (c) 2026 R1nk1
-- Licensed under the R1 Non-Monetized Modpack License v1.0
-- License: https://github.com/noname-r1nk1/R1-License
-- Original Anomaly/GSC and SSS code retains its original authorship and terms.
-- Preserve the vanilla static alpha-tree material when the engine enables
-- tree_branch globally. Verified vanilla usage: veh\veh_chp75b on Jupiter
-- and Truck Cemetery. Its THM has diffuse+normal detail and the installed
-- renderer has r2_detail_bump on. This scoped compatibility pass requires that
-- configuration; custom maps/materials and changed THMs need a new audit.
function setup(shader,t_base)
    shader:sorting(1,false):fog(false):zb(true,true):blend(false,blend.one,blend.zero)
    shader:dx10stencil(true,cmp_func.always,255,127,
        stencil_op.keep,stencil_op.replace,stencil_op.keep):dx10stencil_ref(1)
    shader:dx10texture("s_base",t_base)
    shader:dx10texture("s_bump",t_base.."_bump")
    shader:dx10texture("s_bumpX",t_base.."_bump#")
    shader:dx10texture("s_waves","fx\\wind_wave")
    shader:dx10sampler("smp_base")
    shader:dx10sampler("smp_linear")
    shader:dx10sampler("smp_linear2")
end
function normal_hq(shader,t_base,t_second,t_detail)
    shader:begin("deffer_tree_s_bump_d-hq","deffer_base_aref_bump_db-hq")
    def_shaders_def_objects_lod_trans.setup(shader,t_base)
    shader:dx10texture("s_detail",t_detail)
    shader:dx10texture("s_bumpD",t_detail)
    shader:dx10texture("s_detailBump",t_detail.."_bump")
    shader:dx10texture("s_detailBumpX",t_detail.."_bump#")
end
function normal(shader,t_base,t_second,t_detail)
    shader:begin("deffer_tree_s_bump","deffer_base_aref_bump")
    def_shaders_def_objects_lod_trans.setup(shader,t_base)
end
-- In the DX11 renderer element 2 is the shadow-map pass.
function l_point(shader,t_base,t_second,t_detail)
    shader:begin("shadow_direct_tree_s_aref","shadow_direct_base_aref")
        :sorting(1,false):fog(false):zb(true,true):blend(true,blend.zero,blend.one)
        :aref(true,200):dx10color_write_enable(false,false,false,false)
    shader:dx10texture("s_base",t_base)
    shader:dx10texture("s_waves","fx\\wind_wave")
    shader:dx10sampler("smp_base")
    shader:dx10sampler("smp_linear")
    shader:dx10sampler("smp_linear2")
end
