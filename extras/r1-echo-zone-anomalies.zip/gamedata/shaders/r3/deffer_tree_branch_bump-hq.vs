// R1nk1 modifications only: automatic dispatch / foliage integration.
// Copyright (c) 2026 R1nk1
// Licensed under the R1 Non-Monetized Modpack License v1.0
// License: https://github.com/noname-r1nk1/R1-License
// Original Anomaly/GSC and SSS code retains its original authorship and terms.
// R1 Echo: automatic shader-stack selection, no installer choice.
#define USE_PARALLAX
#include "common.h"
#ifdef SSFX_MV_LOADED
/**
 * @ Version: SCREEN SPACE SHADERS - UPDATE 19
 * @ Description: Trees - Branches/Bushes
 * @ Modified time: 2025-04-05 15:36:32
 * @ Author: https://www.moddb.com/members/ascii1457
 * @ Mod: https://www.moddb.com/mods/stalker-anomaly/addons/screen-space-shaders
 */

#include "common.h"
#include "check_screenspace.h"

#include "screenspace_mvectors.h"

float4 benders_prevpos[32]; // Prev Frame
float4 benders_pos[32]; // Current Frame
float4 benders_setup;

uniform float4 ssfx_floravariation; // Grass Int, Grass Freq, Foliage Int, Foliage Freq

uniform float3x4	m_xform		;
uniform float3x4	m_xform_v	;
uniform float4 		consts; 	// {1/quant,1/quant,???,???}
uniform float4 		c_scale,c_bias,wind,wave;
uniform float2 		c_sun;		// x=*, y=+

#ifdef SSFX_WIND
	#include "screenspace_wind.h"
#endif

v2p_bumped 	main 	(v_tree I)
{
	I.Nh	=	unpack_D3DCOLOR(I.Nh);
	I.T		=	unpack_D3DCOLOR(I.T);
	I.B		=	unpack_D3DCOLOR(I.B);

	// Transform to world coords

	float3 	pos			= mul(m_xform, I.P);
	float 	H			= pos.y - m_xform._24; // height of vertex
	float2	tc			= (I.tc * consts).xy;

	float4 P_prev = 0;

#ifndef SSFX_WIND
	float 	base 	= m_xform._24	;		// take base height from matrix
	float 	dp		= calc_cyclic  	(wave.w+dot(pos,(float3)wave));
	float 	frac 	= I.tc.z*consts.x;		// fractional (or rigidity)
	float 	inten 	= H * dp;				// intensity
	float2 	result	= calc_xz_wave	(wind.xz*inten*2.0f, frac);

	float3 wind_result = float3(result.x, 0, result.y);
#else
	float3 wind_result	= ssfx_wind_tree_branches(pos, H, tc.y, ssfx_wind_setup(), false);

	// Prev Position
	P_prev = float4(pos.xyz + ssfx_wind_tree_branches(pos, H, tc.y, ssfx_wind_setup(), true), 1);
#endif

#ifdef		USE_TREEWAVE
			wind_result	= 0;
#endif
	float4 	w_pos 	= float4(pos.xyz + wind_result.xyz, 1);
	
	
	// INTERACTIVE GRASS ( Bushes ) - SSS Update 15.4
	// https://www.moddb.com/mods/stalker-anomaly/addons/screen-space-shaders/
#if SSFX_INT_GRASS > 0
	for (int b = 0; b < SSFX_INT_GRASS + 1; b++)
	{
		// Direction, Radius & Bending Strength, Distance and Height Limit
		float3 dir = benders_pos[b + 16].xyz;
		float3 rstr = float3(benders_pos[b].w, benders_pos[b + 16].ww); // .x = Radius | .yz = Str
		bool non_dynamic = rstr.x <= 0 ? true : false;
		float dist = distance(w_pos.xz, benders_pos[b].xz);
		float height_limit = 1.0f - saturate(abs(pos.y - benders_pos[b].y) / ( non_dynamic ? 2.0f : rstr.x ));
		height_limit *= (1.0f - tc.y); // Bushes uses UV Coor instead of H to limit displacement

		// Adjustments ( Fix Radius or Dynamic Radius )
		rstr.x = non_dynamic ? benders_setup.x : rstr.x;
 		rstr.yz *= non_dynamic ? benders_setup.yz : 1.0f;

		// Strength through distance and bending direction.
		float bend = 1.0f - saturate(dist / (rstr.x + 0.001f));
		float3 bend_dir = normalize(w_pos.xyz - benders_pos[b].xyz) * bend;
		float3 dir_limit = dir.y >= -1 ? saturate(dot(bend_dir.xyz, dir.xyz) * 5.0f) : 1.0f; // Limit if nedeed

		// Apply direction limit
		bend_dir.xz *= dir_limit.xz;

		// Apply vertex displacement
		w_pos.xz += bend_dir.xz * 2.25f * rstr.yy * height_limit; 		// Horizontal
		w_pos.y -= bend * 0.67f * rstr.z * height_limit * dir_limit.y;	// Vertical
	}

	// Prev Frame
	for (int p = 0; p < SSFX_INT_GRASS + 1; p++)
	{
		// Direction, Radius & Bending Strength, Distance and Height Limit
		float3 dir = benders_prevpos[p + 16].xyz;
		float3 rstr = float3(benders_prevpos[p].w, benders_prevpos[p + 16].ww);
		bool non_dynamic = rstr.x <= 0 ? true : false;
		float dist = distance(P_prev.xz, benders_prevpos[p].xz);
		float height_limit = 1.0f - saturate(abs(P_prev.y - benders_prevpos[p].y) / ( non_dynamic ? 2.0f : rstr.x ));
		height_limit *= (1.0f - tc.y); // Bushes uses UV Coor instead of H to limit displacement

		// Adjustments ( Fix Radius or Dynamic Radius )
		rstr.x = non_dynamic ? benders_setup.x : rstr.x;
 		rstr.yz *= non_dynamic ? benders_setup.yz : 1.0f;

		// Strength through distance and bending direction.
		float bend = 1.0f - saturate(dist / (rstr.x + 0.001f));
		float3 bend_dir = normalize(P_prev.xyz - benders_prevpos[p].xyz) * bend;
		float3 dir_limit = dir.y >= -1 ? saturate(dot(bend_dir.xyz, dir.xyz) * 5.0f) : 1.0f; // Limit if nedeed

		// Apply direction limit
		bend_dir.xz *= dir_limit.xz;

		P_prev.xz += bend_dir.xz * 2.25f * rstr.yy * height_limit; 			// Horizontal
		P_prev.y -= bend * 0.67f * rstr.z * height_limit * dir_limit.y;		// Vertical
	}
#endif
	
	
	float 	hemi 	= clamp(I.Nh.w * c_scale.w + c_bias.w, 0.3f, 1.0f); // Limit hemi - SSS Update 14.5
//	float 	hemi 	= I.Nh.w;

	// Eye-space pos/normal
	v2p_bumped 		O;
	float3	Pe		= mul		(m_V,  	w_pos		);
	O.tcdh 			= float4	(tc.xyyy			);
	O.hpos 			= mul		(m_VP,	w_pos		);
	O.position		= float4	(Pe, 	hemi		);

	// Values to calc motion vectors
	O.vel_curr = O.hpos;
	O.vel_prev = mul(m_vp_prev, P_prev);

	float2 tree_pos = m_xform._14_34 + m_xform._11_11 * 10;
	O.sss_extra = float4(0, 0, hash12(floor(tree_pos * ssfx_floravariation.w)), H);
	
	// Test TAA
	O.hpos.xy = ssfx_taa_jitter(O.hpos);

#if defined(USE_R2_STATIC_SUN) && !defined(USE_LM_HEMI)
	float 	suno 	= I.Nh.w * c_sun.x + c_sun.y	;
	O.tcdh.w		= suno;					// (,,,dir-occlusion)
#endif

	// Calculate the 3x3 transform from tangent space to eye-space
	// TangentToEyeSpace = object2eye * tangent2object
	//		     = object2eye * transpose(object2tangent) (since the inverse of a rotation is its transpose)
	//Normal mapping
	float3 N = normalize(I.P.xyz); //Spherical normals trick
	float3 B = float3(0,0,1);

	if (abs(dot(N, B)) > 0.99f) 
		B = float3(0,1,0);
		
	float3 T = normalize(cross(N, B));
	B = normalize(cross(N, T));	
	
	float3x3 xform	= mul	((float3x3)m_xform_v, float3x3(
						T.x,B.x,N.x,
						T.y,B.y,N.y,
						T.z,B.z,N.z
					));

	// The pixel shader operates on the bump-map in [0..1] range
	// Remap this range in the matrix, anyway we are pixel-shader limited :)
	// ...... [ 2  0  0  0]
	// ...... [ 0  2  0  0]
	// ...... [ 0  0  2  0]
	// ...... [-1 -1 -1  1]
	// issue: strange, but it's slower :(
	// issue: interpolators? dp4? VS limited? black magic?

	// Feed this transform to pixel shader
	O.M1 			= xform[0];
	O.M2 			= xform[1];
	O.M3 			= xform[2];

#ifdef 	USE_TDETAIL
	O.tcdbump		= O.tcdh * dt_params;		// dt tc
#endif

	return O;
}
FXVS;
#else
// Echo foliage: stock tree vertex path.
#include "deffer_tree_bump-hq.vs"

#endif
