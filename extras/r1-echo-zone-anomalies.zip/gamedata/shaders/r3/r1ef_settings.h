// Copyright (c) 2026 R1nk1
// Licensed under the R1 Non-Monetized Modpack License v1.0
// License: https://github.com/noname-r1nk1/R1-License
#ifndef R1EF_SETTINGS_H
#define R1EF_SETTINGS_H
// Shader module settings; restart and invalidate changed branch shader cache.
#define R1EF_DENSITY 0.075
#define R1EF_SATURATION 0.60
#define R1EF_STRENGTH 0.90
#define R1EF_METRES_PER_COLOUR 45.0
#define R1EF_MAX_DISTANCE 76.0
#endif
