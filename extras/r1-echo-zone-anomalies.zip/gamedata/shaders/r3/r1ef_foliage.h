// Copyright (c) 2026 R1nk1
// Licensed under the R1 Non-Monetized Modpack License v1.0
// License: https://github.com/noname-r1nk1/R1-License
#ifndef R1EF_FOLIAGE_H
#define R1EF_FOLIAGE_H
#include "r1ef_settings.h"
float r1ef_hash(float2 p) {
    float3 q=frac(float3(p.x,p.y,p.x)*0.1031);
    q+=dot(q,q.yzx+33.33);
    return frac((q.x+q.y)*q.z);
}
float3 r1ef_palette(float index,float3 original,float lum) {
    if(index<0.5) return original;
    float3 colour;
    if(index<1.5) colour=lum*float3(1.58,1.18,0.20);
    else if(index<2.5) colour=lum*float3(1.80,0.35,0.12);
    else if(index<3.5) colour=lum*float3(0.40,1.27,0.24);
    else colour=lum*float3(0.36,0.39,0.42);
    float grey=dot(colour,float3(0.2126,0.7152,0.0722));
    return lerp(float3(grey,grey,grey),colour,R1EF_SATURATION);
}
float3 r1ef_colour(float3 original,float3 root,float3 eye,float distanceToPixel,float inverseHQRange) {
    float seed=r1ef_hash(floor(root.xz*4.0)*0.25);
    // Uniform per tree; no time, camera heading, shared Lua constants or textures.
    if(seed>=R1EF_DENSITY) return original;
    float limit=min(R1EF_MAX_DISTANCE,0.65/max(inverseHQRange,0.001));
    float weight=(1-smoothstep(limit*0.65,limit,distanceToPixel))*R1EF_STRENGTH;
    // Protect brown twigs within alpha leaf atlases, as well as separate trunks.
    weight*=smoothstep(0.72,0.98,original.g/max(original.r,0.001));
    if(weight<=0) return original;
    float2 direction=normalize(float2(0.45+seed*1.3,0.85-seed*0.8));
    float phase=dot(eye.xz-root.xz,direction)/R1EF_METRES_PER_COLOUR+seed*29.0;
    float cell=floor(phase), t=frac(phase);
    t=t*t*(3-2*t);
    float a=cell-5*floor(cell/5), b=a+1;
    if(b>4.5)b=0;
    float lum=dot(original,float3(0.2126,0.7152,0.0722));
    float3 colour=lerp(r1ef_palette(a,original,lum),r1ef_palette(b,original,lum),t);
    return lerp(original,saturate(colour),saturate(weight));
}
#endif
