[2.0.2] Grok's Body Health System Redux

DESCRIPTION

An updated and fixed version of Body Health System with a new HUD compatible with Anomaly 1.5.1.


Major changes:

- Damages are now properly attributed to limbs. A bullet in your belly won't damage your head, only your torso.
- Fall damage are now damaging your legs.
- New sexy HUD compatible with gas masks overlays.
- Better description of medical items (which limb is healed, by which amount, etc).
- You can spam consumables, no more "there's already an active effect".


CHANGELOG

1.0.0 : first upload
1.1.0 : Removed Ultimate BHS Patch modification of healing items (conflicts + bugs + very minor changes to eat health decrease so I removed it).
	Medical Bags can now be unpacked.
	New script to move the PDA notification icon based on RavenAscendant's code.
	HUD is now above gas masks overlays (Grok's Masks, Nav's Masks).
1.3.0 :	Toxic and Heat are redirected to head or torso randomly
	Radiation should damage - rarely - head or torso
	Unknown bones hit (fingers most likely) hit one arm or torso (failsafe).
	Fixed Etperazine healing
	Fixed Vinca description
	Added Survival Kit description
	New extended HUD (PDA messages might overlap a bit, you can still use the previous UI).
1.4.0:	Changed HUD position for the healing items.
	UI is not overlapping with PDA messages anymore.
	HUD is now a bit more transparent.
	Fixed a healing items pack content description.
	Added a Respawn Mode compatibility Patch
	Added Grok's Mask Patch (helmets are kept on for the various actions)
	Added Navs's Mask Patch (helmets are kept on for the various actions)
1.5.0:
	Added a Patch to remove quickslots and it's associated box.
	Fixed the issue of weird symbols in the top left corner.
	Renamed Patches to be more descriptive.

1.5.0b:
	Hotfix for Text based UI Patch (aa to zzz script name to match main script name).

1.6.1:
	Food Drugs and Animations + Grok's or Nav's Masks Patch (HUD is not hidden while drinking  / etc with FDDA).
	Introduction of a new rework of debuffs based on limb health, courtesy of xcvb, real big brain, and balanced by yours trully.
		- When Arms loose a certain amount of HP, your view while aiming down sight starts to sway. The heavier the weapon and the less health your arms have, the bigger the sway.
		- When your Legs are damaged below a certain threshold, you start limping. You can still run. However running and sprinting speeds are reduced. Moreover, running will occasionnaly cause extreme pain and health loss (sounds from Desman voice pack included).
	Reorganisation of the archive folder.
	Removal of the damaging property of most healing items (stims notably). Cocain is still hurting you, don't do drugs.
	Drugs post-heals rebalance.
	Drugs description update, removing some misleading debuffs and updating the new post-heals values.

1.6.2:
	Used the correct limb effects script (uploaded the wrong old one in 1.6.1): better limping animations blending and more progressive limping, stronger aim drift when arms are damaged.
	Fixed HUD Stretch for DX8 and DX9.
	Improved Akvatabs healing.
	Further fixed and improved drugs description. Dizziness follows 4 categories : slight, moderate, severe and extreme dizziness.

1.6.3:
	Reworked limb effects so that limping starts later (only when legs are damaged enough).
	Added limb effects in the base mod.
	Added an optional patch to remove limb effects.
	Updated FDDA patch for 0.8.5 version.
	Fixed healing of some post-healing items (Vinca).
	Introduced a new UI patch for Square DOV addon.
	Fixed items healing properties for Text-Based UI.
1.6.4:
	Anims and sounds hotfix for 1.6.3.

1.6.5: 
	Added speed modifiers compatible with Powered Exos and Outfits Affect Movement Speed addons.
	Removed a wrong file in the PATCH FDDA + Masks.

1.6.6:
	Fixed Text Based HUD Patch
	Introduced a new version of the Text Based HUD for VODIS and co, don't forget to untick "auto-hide stamina bar" in the options.

1.6.7: 
	FOMOD Support for installation through MO2.
	Medic now heals your limbs. Thanks to ForeverButthurt.
	New universal patch for FDDA + Masks by FeelFried.

2.0.0:
	New EFT UI supporting the BHS Full HUD and HUD customisation with ammo position (reupload and rework of EFT UI for GBHSR).
	Ammo Checker patch.
	Added changes made by xcvb TEST version (1.6.X v0.4) :
		New limb penalties for Head.
		New limb penalties for Torso.
		Added MCM support.
		Fixed broken legs damaging other body parts.
		Fixed (kinda) old bug when disabled HUD will drop your FPS harder than pip scope.

2.0.1:
	Made some tables global for compatibility with some upcoming addons. They can be accessed in other scripts by using zzz_player_injuries.maxhp, zzz_player_injuries.health for instance.
	
2.0.2:
	Compatibility with xcvb Detailed Description addon.