MMX-T.H.A.P Rework Patch

Local patch for T.H.A.P. Rework 2.3. It keeps the original diffuse hand texture and disables the hand texture's bump mapping in its THM metadata, including the bump strength and reference. It contains no T.H.A.P. DDS texture assets.

The installed T.H.A.P. files are not modified in this source folder. MMX installs this one-file override and can restore the active T.H.A.P. metadata when this patch is uninstalled.
Credit for T.H.A.P. Rework 2.3: IENCE. Original source: https://www.moddb.com/mods/stalker-anomaly/addons/thap-rework
