MMX - Health [Anomaly] v0.2.0
================================

Prima build sperimentale inclusa automaticamente nel profilo MMX-Base.

Obiettivo
---------
Preparare fix prestazionali selettivi per gli hitch di Anomaly senza toccare:
  - file .ltx e fingerprint coop;
  - MCM;
  - animazioni, HUD e LTX di LTX;
  - audio;
  - script centrali o patch invasive di altre mod.

Comportamento v0.1.0
--------------------
- Rileva MMX-Core, R1 Echo Zone e Dynamic Anomalies una sola volta.
- Non duplica il fix casse/particellari già fornito da MMX-Core.
- Se un runtime non è presente, salta solo il controllo relativo e scrive il motivo nel log.
- Non applica ancora un cap a R1/Dynamic Anomalies: il cap senza profiling può ridurre qualità,
  alterare il comportamento delle anomalie o interferire con un aggiornamento futuro.
- Nessun audio viene modificato.
- Il pacchetto è installabile e scaricabile dal feed come essenziale MMX-Base;
  il contenuto resta diagnostico e non promette ancora un miglioramento prestazionale.

Test previsto
-------------
1. Avviare MMX Experimental con MMX-Health attiva.
2. Riprodurre la rottura casse e gli eventi che creano il muro/superficie anomala.
3. Confrontare fluidità e log tra MMX-Health attiva e parcheggiata.
4. Solo dopo il confronto aggiungere fix mirati, ciascuno con gate, log e skip autonomo.

Probe renderer v0.2.0
---------------------
- Legge una sola volta il renderer e gli eventuali cvar DLSS/FSR già esposti dalla build.
- Non attiva l'upscaler, non modifica cvar, non carica DLL e non sostituisce eseguibili.
- Se DX11/R4 non è confermato, salta il controllo grafico e lascia il rendering nativo.
- Se l'utente ha già selezionato DLSS o FSR, MMX-Health non lo modifica.
- Il probe serve solo a decidere il prossimo test sicuro e scrive l'esito nel log.

Nota
----
Il fix delle casse non viene duplicato: è già in MMX-Core tramite MMX_CORE_hitch_particles.script
e gli override box_*.ltx. MMX-Health si occuperà della parte residua dopo la misura degli eventi
R1/Dynamic Anomalies.

