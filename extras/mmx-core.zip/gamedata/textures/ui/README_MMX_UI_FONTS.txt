﻿MMX UI fonts — stato (Core 0.1.5)

JOIN / HELLO
------------
fonts.ltx = VANILLA Anomaly (SHA allineato overlay pack). Entrambi i PC
stesso file → niente cfg-diff fonts. Nessuna API per escludere fonts dal
fingerprint EXE: non aggiungere sezioni extra in fonts.ltx senza rollout
coordinato (vedi VERSIONS/MMX_CORE_FONTS_AVANT_GARDE_ALIASES.txt).

DISPLAY
-------
graffiti19/22/32 = atlas in textures/ui/ui_font_graff_* (override Core).
ui_font_mmx_elegant_* / ui_font_mmx_avant_garde_* = atlas dedicati (cosmetic).
DDS ≠ fingerprint. Elegant vs vanilla OK per join.

Builder: Assets/Fonts/build_mmx_elegant_anomaly_fonts.py
TTF Elegant NON incluso (licenza personal use).
