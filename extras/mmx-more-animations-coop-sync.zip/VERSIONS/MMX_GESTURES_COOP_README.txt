MMX-More Animations For Anomaly 1.5.3 for Coop Sync (MMX-Net / Logan)

Upstream (install separately — Opzionale improved-gestures):
  [ Improved Gestures Tool ] More Animations For Anomaly 1.5.2 - 1.5.3 | V2.0.0
  Author/uploader: Relax_68
  Credits: VodoXleb (original), TheMrDemonized, lexus, xcvb
  ModDB: https://www.moddb.com/mods/stalker-anomaly/addons/improved-gestures-tool-for-anomaly-153

This pack: MMX_NET_patch_improved_gestures.script only — no Relax_68 assets.

Coop MVP (honest):
  - Peer dummy alife spawn blocked on client; SendPeerAnim relay for remote visuals.
  - Smoke subset in MVP_ANIM_MAP — not all 146 gestures.
  - Join without improved-gestures or this pack: OK.

Smoke checklist (2P):
  1) Host + peer both have improved-gestures + this optional.
  2) Host starts a mapped sit/guitar pose → peer sees proxy anim.
  3) Stop (U / cancel) or move → relay clears.
  4) Third player without mod can still join session.
